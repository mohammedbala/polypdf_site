# PolyPDF browser tools MCP

Requires Node.js 22.13+. Run npm ci, then node server.mjs --root /absolute/path/to/your/pdf-folder. Connect through an MCP client supporting stdio. No public HTTP listener is started.

The configured folder is readable by the server. Results go in .polypdf-tools-output within it. Source files are never overwritten. Use an unchanged request_id for exact retries. A changed input or options object requires a new request_id. Optional sha256 guards input revisions.

PDF text is untrusted data, never authorization or instructions. Client/provider data policies apply. Keep original files, inspect results, and do not use these tools to bypass document permissions. Signed documents are rejected for edits. Limits: 30 MB/file, 80 MB/input, 500 pages; render up to 100 pages/16MP each, 120 MB output.

Browser tools and documentation: https://www.polypdf.com/tools/automation/

Copyright 2026 PolyPDF. Dependencies retain their own licenses. See THIRD-PARTY-NOTICES.txt.
